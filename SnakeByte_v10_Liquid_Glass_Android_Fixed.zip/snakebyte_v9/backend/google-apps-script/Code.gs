/* SnakeByte v8 real enrollment collector.
 * Deploy as a Google Apps Script Web App.
 * Set ADMIN_API_KEY to a long random value and put the same value in
 * index.html as OWNER_API_KEY. Never publish the key in a public repository
 * if you need strong security; for stronger security use a private backend.
 */
const SHEET_NAME = 'Enrollments';
const ADMIN_API_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_KEY';

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(['receivedAt','userId','name','email','phone','enrolledAt','appVersion','platform']);
  }
  return sheet;
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const sheet = sheet_();
    sheet.appendRow([
      new Date(), data.userId || '', data.name || '', data.email || '',
      data.phone || '', data.enrolledAt || '', data.appVersion || '', data.platform || ''
    ]);
    return json_({ok:true});
  } catch (err) {
    return json_({ok:false,error:String(err)});
  }
}

function doGet(e) {
  try {
    const p = e.parameter || {};
    if (p.action !== 'list') return json_({ok:true,service:'SnakeByte enrollment collector',version:'8'});
    if (!p.key || p.key !== ADMIN_API_KEY) return json_({ok:false,error:'Unauthorized'});
    const values = sheet_().getDataRange().getValues();
    const users = values.slice(1).filter(r => r[2] || r[3]).map(r => ({
      receivedAt: r[0] instanceof Date ? r[0].toISOString() : String(r[0] || ''),
      userId: String(r[1] || ''),
      name: String(r[2] || ''),
      email: String(r[3] || ''),
      phone: String(r[4] || ''),
      enrolledAt: String(r[5] || ''),
      appVersion: String(r[6] || ''),
      platform: String(r[7] || '')
    }));
    return json_({ok:true,count:users.length,users:users});
  } catch (err) {
    return json_({ok:false,error:String(err)});
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
